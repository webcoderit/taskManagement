<script src="{{ asset('backend/') }}/assets/js/bootstrap.bundle.min.js"></script>
	<!--plugins-->
	<script src="{{ asset('backend/') }}/assets/js/jquery.min.js"></script>
	<script src="{{ asset('backend/') }}/assets/plugins/simplebar/js/simplebar.min.js"></script>
	<script src="{{ asset('backend/') }}/assets/plugins/metismenu/js/metisMenu.min.js"></script>
	<script src="{{ asset('backend/') }}/assets/plugins/perfect-scrollbar/js/perfect-scrollbar.js"></script>
	<script src="{{ asset('backend/') }}/assets/plugins/vectormap/jquery-jvectormap-2.0.2.min.js"></script>
	<script src="{{ asset('backend/') }}/assets/plugins/vectormap/jquery-jvectormap-world-mill-en.js"></script>
	<script src="{{ asset('backend/') }}/assets/plugins/highcharts/js/highcharts.js"></script>
	<script src="{{ asset('backend/') }}/assets/plugins/highcharts/js/exporting.js"></script>
	<script src="{{ asset('backend/') }}/assets/plugins/highcharts/js/variable-pie.js"></script>
	<script src="{{ asset('backend/') }}/assets/plugins/highcharts/js/export-data.js"></script>
	<script src="{{ asset('backend/') }}/assets/plugins/highcharts/js/accessibility.js"></script>
	<script src="{{ asset('backend/') }}/assets/plugins/apexcharts-bundle/js/apexcharts.min.js"></script>
    <script src="{{ asset('backend/') }}/assets/plugins/datatable/js/jquery.dataTables.min.js"></script>
    <script src="{{ asset('backend/') }}/assets/plugins/datatable/js/dataTables.bootstrap5.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <script>
        $(document).ready(function() {
            $('#example').DataTable();
        } );
    </script>
    <script>
		new PerfectScrollbar('.dashboard-top-countries');
	</script>
	<script src="{{ asset('backend/') }}/assets/js/index2.js"></script>
	<!--app JS-->
	<script src="{{ asset('backend/') }}/assets/js/app.js"></script>
	<script src="{{ asset('backend/') }}/assets/js/custom.js"></script>
<script>
    new PerfectScrollbar('.customers-list');
    new PerfectScrollbar('.store-metrics');
    new PerfectScrollbar('.product-list');
</script>
