<?php $__env->startSection('content'); ?>
<div class="wrapper">
    <div class="page-wrapper" style="margin-left: 20px!important;">
        <div class="page-content">
            <!--breadcrumb-->
            <div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
                <div class="breadcrumb-title pe-3">Today Task</div>
                <div class="ps-3">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb mb-0 p-0">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('/employee/dashboard')); ?>"><i class="bx bx-home-alt"></i></a>
                            </li>
                            <!-- <li class="breadcrumb-item active" aria-current="page">
                                <a href="#">List Task</a>
                            </li>  -->
                            <li class="breadcrumb-item active" aria-current="page">Today Task</li>
                        </ol>
                    </nav>
                </div>
            </div>
            <!--end breadcrumb-->
            <h6 class="mb-0 text-uppercase">Today Task</h6>
            <hr/>
            <div class="card">
                <div class="card-body">
                    <form class="form-group" action="<?php echo e(url('/today/task')); ?>" method="get">
                        <?php echo csrf_field(); ?>
                        <div class="col-md-12" style="padding-left: 10%;">
                            <div class="row">
                                <div class="col-md-2"></div>
                                <div class="col-md-6">
                                    <input type="search" name="search" class="form-control" placeholder="Enter Phone Number & Full Name">
                                </div>
                                <div class="col-md-2">
                                    <div class="input-group">
                                        <button type="submit" class="input-group-text btn btn-primary" id="basic-addon2">Search</button>
                                        <a href="<?php echo e(url('/today/task')); ?>" class="input-group-text btn btn-danger" id="basic-addon2">Clear</a>
                                    </div>
                                </div>
                                <div class="col-md-2" style="text-align-last: end;"></div>
                            </div>
                        </div>
                    </form>
                    <div class="table-responsive">
                        <table id="" class="table table-striped table-bordered" style="width:100%">
                            <thead>
                            <tr>
                                <th>SL</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Phone</th>
                                <th>Profession</th>
                                <th>Laptop/PC</th>
                                <th>Action</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $todayTask; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->index+1); ?></td>
                                    <td><?php echo e($task->name ?? ''); ?></td>
                                    <td><?php echo e($task->email ?? ''); ?></td>
                                    <td><?php echo e($task->phone ?? ''); ?></td>
                                    <td><?php echo e($task->profession ?? ''); ?></td>
                                    <td><?php echo e($task->device ?? ''); ?></td>
                                    <td width="15%">
                                        <?php if($task->status == 0): ?>
                                        <a href="<?php echo e(url('/view/details/'.$task->id)); ?>" class="btn btn-sm btn-primary">
                                            <i class="bx bx-edit-alt"></i>
                                            View
                                        </a>
                                        <?php else: ?>
                                            <a href="#" class="btn btn-sm btn-success" disabled>
                                                <i class="bx bx-check-circle"></i>
                                                Call Done
                                            </a>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <?php echo e($todayTask->links()); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\taskManagement\resources\views/backend/users/task/today-task.blade.php ENDPATH**/ ?>