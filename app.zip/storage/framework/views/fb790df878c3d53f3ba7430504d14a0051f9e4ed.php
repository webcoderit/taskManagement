<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Batch wise student report PDF</title>
</head>
<body>
    <table style="border: 1px solid #000000; margin: auto; height: auto; width: 100%">
        <thead>
            <tr style="background-color: #0bb2d3">
                <th>SL</th>
                <th>Marketing Officer Name</th>
                <th>Name</th>
                <th>Email</th>
                <th>Phone</th>
                <th>Course Name</th>
                <th>Batch No</th>
                <th>Course Fee</th>
                <th>Advance</th>
                <th>Due</th>
                <th>Due Opinion</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $admissionStudents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admissionStudent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td style="border: 1px solid #000"><?php echo e($loop->index+1); ?></td>
                <td style="border: 1px solid #000"><?php echo e($admissionStudent->user->full_name?? ''); ?></td>
                <td style="border: 1px solid #000"><?php echo e($admissionStudent->s_name?? ''); ?></td>
                <td style="border: 1px solid #000"><?php echo e($admissionStudent->s_email ?? ''); ?></td>
                <td style="border: 1px solid #000"><?php echo e($admissionStudent->s_phone ?? ''); ?></td>
                <td style="border: 1px solid #000">
                    <?php if($admissionStudent->course == 'web'): ?>
                        WEB
                    <?php elseif($admissionStudent->course == 'digital'): ?>
                        ADM
                    <?php else: ?>
                        ENG
                    <?php endif; ?>
                </td>
                <td style="border: 1px solid #000"><?php echo e($admissionStudent->batch_no?? ''); ?></td>
                <td style="border: 1px solid #000"><?php echo e($admissionStudent->moneyReceipt->total_fee ?? ''); ?>Tk.</td>
                <td style="border: 1px solid #000"><?php echo e($admissionStudent->moneyReceipt->advance ?? ''); ?>Tk.</td>
                <td style="border: 1px solid #000">
                    <?php if($admissionStudent->moneyReceipt->due == 0): ?>
                        Paid
                    <?php else: ?>
                        <?php echo e($admissionStudent->moneyReceipt->due ?? ''); ?>

                    <?php endif; ?>
                </td>
                <td style="border: 1px solid #000"><?php echo e($admissionStudent->note ?? ''); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        <tr>
            <td style="font-weight: 700" colspan="11">This batch Total Students : <?php echo e(count($admissionStudents)); ?></td>
        </tr>
    </table>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\taskManagement\resources\views/backend/admin/pdf/batch-student-pdf.blade.php ENDPATH**/ ?>