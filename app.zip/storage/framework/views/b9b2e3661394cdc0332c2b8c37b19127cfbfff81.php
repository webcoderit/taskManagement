<?php $__env->startSection('title'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="page-content">
    <div class="">
        <!--Admission debit and credit calculation-->
        <div class="row row-cols-1 row-cols-md-2 row-cols-xl-5 row-cols-xxl-5">
            <div class="col">
                <div class="card radius-10" style="background-color: #0bb2d3">
                    <div class="card-body text-center">
                        <p class="mb-1 text-white">Today Admission Advance</p>
                        <h3 class="mb-3 text-white">
                            <?php echo e(number_format($data['todayAmountsAdvance']->sum('advance'),2 ?? 0)); ?>

                        </h3>
                        <span style="background-color: purple;
                            color: white;
                            padding: 10px 40px;
                            font-size: 16px;
                            font-weight: 700;
                            border-radius: 5px;">
                            <?php echo e(count(\App\Models\MoneyReceipt::whereDate('admission_date', \Carbon\Carbon::today())->get())); ?>

                        </span>
                        <div id="chart1"></div>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="card radius-10" style="background-color: darkred">
                    <div class="card-body text-center">
                        <p class="mb-1 text-white">Today Admission Due</p>
                        <h3 class="mb-3 text-white"><?php echo e(number_format($data['todayAmountsDue']->sum('due'),2 ?? 0)); ?></h3>
                        <div id="chart4"></div>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="card radius-10" style="background-color: deepskyblue">
                    <div class="card-body text-center">
                        <p class="mb-1 text-white">Monthly Admission Advance</p>
                        <h3 class="mb-3 text-white"><?php echo e(number_format($data['monthlyAmountsAdvance']->sum('advance'),2 ?? 0)); ?></h3>
                        <div id="chart2"></div>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="card radius-10" style="background-color: rebeccapurple">
                    <div class="card-body text-center">
                        <p class="mb-1 text-white">Monthly Admission Due</p>
                        <h3 class="mb-3 text-white"><?php echo e(number_format($data['monthlyAmountsDue']->sum('due'),2 ?? 0)); ?></h3>
                        <div id="chart3"></div>
                    </div>
                </div>
            </div>
            <div class="col col-md-12">
                <div class="card radius-10" style="background-color: orangered">
                    <div class="card-body text-center">
                        <p class="mb-1 text-white">Today Due Collect</p>
                        <h3 class="mb-3 text-white"><?php echo e(\App\Models\MoneyReceipt::whereDate('updated_at', \Carbon\Carbon::today())->sum('today_pay')); ?></h3>
                        <div id="chart5"></div>
                    </div>
                </div>
            </div>
            <div class="col col-md-12">
                <div class="card radius-10" style="background-color: hotpink">
                    <div class="card-body text-center">
                        <p class="mb-1 text-white">Monthly Due Collect</p>
                        <h3 class="mb-3 text-white"><?php echo e(\App\Models\MoneyReceipt::whereMonth('updated_at', \Carbon\Carbon::now()->format('m'))->sum('today_pay')); ?></h3>
                        <div id="chart5"></div>
                    </div>
                </div>
            </div>
            <div class="col col-md-12">
                <div class="card radius-10" style="background-color: orangered">
                    <div class="card-body text-center">
                        <p class="mb-1 text-white">Total Due</p>
                        <h3 class="mb-3 text-white"><?php echo e(number_format($totalDue,2 ?? 0)); ?> Tk.</h3>
                        <div id="chart5"></div>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="card radius-10" style="background-color: lightskyblue">
                    <div class="card-body text-center">
                        <p class="mb-1 text-white">Today Expanse</p>
                        <h3 class="mb-3 text-white"><?php echo e(number_format(\App\Models\Expance::whereDate('created_at', \Carbon\Carbon::today())->get()->sum('price'),2)); ?></h3>
                        <div id="chart2"></div>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="card radius-10" style="background-color: darkseagreen">
                    <div class="card-body text-center">
                        <p class="mb-1 text-white">Monthly Expanse</p>
                        <h3 class="mb-3 text-white"><?php echo e(number_format(\App\Models\Expance::whereMonth('created_at', date('m'))->get()->sum('price'),2)); ?></h3>
                        <div id="chart5"></div>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="card radius-10" style="background-color: #CD5C5C">
                    <div class="card-body text-center">
                        <p class="mb-1 text-white">Monthly ADM Admission</p>
                        <h3 class="mb-3 text-white"><?php echo e(count($data['monthlyAdmAdmission']) ?? 0); ?></h3>
                        <div id="chart2"></div>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="card radius-10" style="background-color: #6495ED">
                    <div class="card-body text-center">
                        <p class="mb-1 text-white">Monthly Web Admission</p>
                        <h3 class="mb-3 text-white"><?php echo e(count($data['monthlyWebAdmission']) ?? 0); ?></h3>
                        <div id="chart2"></div>
                    </div>
                </div>
            </div>
            <div class="col col-md-12">
                <div class="card radius-10" style="background-color: #800080">
                    <div class="card-body text-center">
                        <p class="mb-1 text-white">Monthly English Admission</p>
                        <h3 class="mb-3 text-white"><?php echo e(count($data['monthlyEngAdmission']) ?? 0); ?></h3>
                        <div id="chart2"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="search-form-wrapper card p-4">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <form class="form-group" action="<?php echo e(url('/admin/hr/dashboard')); ?>" method="get">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-md-3">
                                <label for="user_id" style="font-weight: 600; margin-bottom: 5px;">
                                    Employee Name
                                </label><br>
                                <select name="user_id" class="form-control">
                                    <option selected disabled>--- Select Employee Name ---</option>
                                    <?php $__currentLoopData = $data['users']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($user->id); ?>"><?php echo e($user->full_name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="col-md-3">
                                <label for="date" style="font-weight: 600; margin-bottom: 5px;">
                                    Date
                                </label><br>
                                <input type="date" name="date" class="form-control" placeholder="Date">
                            </div>
                            <div class="col-md-3">
                                <label for="batch" style="font-weight: 600; margin-bottom: 5px;">
                                    Batch No
                                </label><br>
                                <select name="batch_no" id="batchNo" class="form-control">
                                    <option selected disabled>--- Select Batch No ---</option>
                                    <?php $__currentLoopData = $data['admissionStudentsBatch']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $batchNo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($batchNo->batch_no); ?>"><?php echo e(ucfirst($batchNo->course_name)); ?> - <?php echo e(ucfirst($batchNo->batch_no)); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="col-md-3">
                                <div class="input-group" style="margin-top: 25px;">
                                    <button type="submit" class="input-group-text btn btn-primary">
                                        Search
                                    </button>
                                    <a href="<?php echo e(url('/admin/hr/dashboard')); ?>" class="input-group-text btn btn-danger">
                                        Clear
                                    </a>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <form action="<?php echo e(url('/admin/admission/checked')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <div class="card">
            <div class="card-body">
                <?php if(Session::has('error')): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <strong>Error!</strong> <?php echo e(Session::get('error')); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>
                    <?php if(Session::has('success')): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <strong>Success!</strong> <?php echo e(Session::get('success')); ?>

                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    <?php endif; ?>
                <div class="table-responsive">
                    <table id="" class="table table-striped table-bordered" style="width:100%">
                        <thead>
                        <tr>
                            <th></th>
                            <th>Date</th>
                            <th>Employee Name</th>
                            <th>Course Name</th>
                            <th>Batch</th>
                            <th>Student Name</th>
                            <th>Student Phone</th>
                            <th>Student Email</th>
                            <th>Total Fee</th>
                            <th>Advance</th>
                            <th>Due</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php if(!empty($admissionStudents)): ?>
                            <?php
                                $sum = 0
                            ?>
                            <?php $__currentLoopData = $admissionStudents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admissionStudent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <?php if($admissionStudent->admin_check == null): ?>
                                        <td>
                                            <input type="checkbox" name="admin_check[]" value="<?php echo e($admissionStudent->id); ?>" />
                                        </td>
                                    <?php else: ?>
                                        <td>
                                            <span class="badge rounded-pill bg-success">Checked</span>
                                        </td>
                                    <?php endif; ?>
                                    <td><?php echo e($admissionStudent->moneyReceipt->admission_date->format('Y-m-d')); ?></td>
                                    <td><?php echo e($admissionStudent->user->full_name?? ''); ?></td>
                                    <td>
                                        <?php if($admissionStudent->course == 'web'): ?>
                                            Full stack web development
                                        <?php elseif($admissionStudent->course == 'digital'): ?>
                                            Advanced digital marketing
                                        <?php else: ?>
                                            Communication english
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e($admissionStudent->batch_no?? ''); ?></td>
                                    <td><?php echo e($admissionStudent->s_name?? ''); ?></td>
                                    <td><?php echo e($admissionStudent->s_phone ?? ''); ?></td>
                                    <td><?php echo e($admissionStudent->s_email ?? ''); ?></td>
                                    <td><?php echo e($admissionStudent->moneyReceipt->transaction_id ?? ''); ?></td>
                                    <td><?php echo e($admissionStudent->moneyReceipt->total_fee ?? ''); ?>Tk.</td>
                                    <td><?php echo e($admissionStudent->moneyReceipt->advance ?? ''); ?>Tk.</td>
                                    <td><?php echo e($admissionStudent->moneyReceipt->due ?? ''); ?>Tk.</td>
                                </tr>
                                <?php
                                    $sum += $admissionStudent->moneyReceipt->advance
                                ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td colspan="7"></td>
                                <td>Total Student : <?php echo e(count($admissionStudents) ?? 0); ?></td>
                                <td>
                                    <span style="font-weight: bold">Total Amount : <?php echo e(number_format($sum,2)); ?></span>
                                </td>
                                <td colspan="3">
                                    <button type="submit" class="btn btn-sm btn-success float-end">Update</button>
                                </td>
                            </tr>
                        </tbody>
                        <?php else: ?>
                            <tr>
                                <td colspan="11">
                                    <p class="text-center mt-3">Please Select Employee Name or Batch No or Date and Then Hit Search</p>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </table>
                </div>
            </div>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>





<?php $__env->stopPush(); ?>

<?php echo $__env->make('backend.admin.hr-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\taskManagement\resources\views/backend/admin/hrm/index.blade.php ENDPATH**/ ?>