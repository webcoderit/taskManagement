<?php $__env->startSection('content'); ?>
<div class="wrapper">
    <div class="page-wrapper" style="margin-left: 20px!important;">
        <div class="page-content">
            <!--breadcrumb-->
            <div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
                <div class="breadcrumb-title pe-3">Admission</div>
                <div class="ps-3">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb mb-0 p-0">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('/admin/dashboard')); ?>"><i class="bx bx-home-alt"></i></a>
                            </li>
                            <li class="breadcrumb-item active" aria-current="page">Admission Filtering Count</li>
                        </ol>
                    </nav>
                </div>
            </div>
            <!--end breadcrumb-->
            <h6 class="mb-0 text-uppercase">Admission Filtering Count</h6>
            <hr/>
            <div class="search-form-wrapper card p-4">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <form class="form-group" action="<?php echo e(url('/admin/user/admission/filtering')); ?>" method="get">
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                    <div class="col-md-3">
                                        <label for="batch" style="font-weight: 600; margin-bottom: 5px;">
                                            Batch No:
                                        </label><br>
                                        <select name="batch_no" id="batchNo" class="form-control">
                                            <option selected disabled>--- Select Batch No ---</option>
                                            <?php $__currentLoopData = $data['batch']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $batchNo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($batchNo->batch_no); ?>"><?php echo e(ucfirst($batchNo->course_name)); ?> - <?php echo e($batchNo->batch_no); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="input-group" style="margin-top: 25px;">
                                            <button type="submit" class="input-group-text btn btn-primary">
                                                Search
                                            </button>
                                            <a href="<?php echo e(url('/admin/user/admission/filtering')); ?>" class="input-group-text btn btn-danger">
                                                Clear
                                            </a>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <label for="batch" style="font-weight: 600; margin-bottom: 10px;">
                                            Total Student:
                                        </label><br>
                                        <?php if(isset($admissionStudents) > 0): ?>
                                        <span class="total-student-count">
                                           <?php echo e(count($admissionStudents)); ?>

                                        </span>
                                        <?php endif; ?>
                                        <?php if(isset($admissionStudentsDateFiltering) > 0): ?>
                                        <span class="total-student-count">
                                           <?php echo e(count($admissionStudentsDateFiltering)); ?>

                                        </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </form>
                            <form action="<?php echo e(url('/admin/user/admission/filtering')); ?>" method="get" class="form-group">
                                <?php echo csrf_field(); ?>
                                <div class="col-md-12">
                                    <div class="row">
                                        <div class="col-md-4">
                                            <label>From date</label>
                                            <div class="input-group mb-2">
                                                <input type="date" name="from_date" class="form-control">
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <label>To date</label>
                                            <div class="input-group mb-2">
                                                <input type="date" name="to_date" class="form-control">
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <button type="submit" class="input-group-text btn btn-primary" id="basic-addon2" style="margin-top: 20px;">Search</button>
                                            <a href="<?php echo e(url('/admin/user/admission/filtering')); ?>" class="input-group-text btn btn-danger" id="basic-addon2" style="margin-top: 20px;">Clear</a>

                                            <?php if(isset($admissionStudentsDateFiltering) > 0): ?>
                                                <a href="#" class="input-group-text btn btn-danger" id="basic-addon2" style="margin-top: 20px;"><?php echo e(count($admissionStudentsDateFiltering)); ?></a>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card">
                <div class="card-body">
                    <div class="table-responsive">
                        <?php if(isset($admissionStudentsDateFiltering)): ?>
                        <a href="<?php echo e(url('/admin/user/admission/filtering/report/download/'.request()->from_date . '/' . request()->to_date)); ?>" class="input-group-text btn btn-info float-end" id="basic-addon2" style="">Admission Report Download</a>
                        <?php endif; ?>
                        <table id="" class="table table-striped table-bordered" style="width:100%">
                            <thead>
                            <tr>
                                <th>SL</th>
                                <th>Date</th>
                                <th>Employee Name</th>
                                <th>Course Name</th>
                                <th>Batch</th>
                                <th>Student Name</th>
                                <th>Student Phone</th>
                                <th>Student Email</th>
                                <th>Total Fee</th>
                                <th>Advance</th>
                                <th>Due</th>
                            </tr>
                            </thead>



































                            <?php if(isset($admissionStudentsDateFiltering)): ?>
                                <tbody>
                                <?php
                                    $sum = 0;
                                    $web = 0;
                                    $adm = 0
                                ?>
                                <?php $__currentLoopData = $admissionStudentsDateFiltering; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admissionStudentFilter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->index+1); ?></td>
                                        <td><?php echo e($admissionStudentFilter->admission_date->format('Y-m-d')); ?></td>
                                        <td><?php echo e($admissionStudentFilter->admissionForm->user->full_name?? ''); ?></td>
                                        <td>
                                            <?php if($admissionStudentFilter->admissionForm ? $admissionStudentFilter->admissionForm->course == 'web' : ''): ?>
                                                Full stack web development
                                            <?php elseif($admissionStudentFilter->admissionForm ? $admissionStudentFilter->admissionForm->course == 'digital' : ''): ?>
                                                Advanced digital marketing
                                            <?php else: ?>
                                                Communication english
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo e($admissionStudentFilter->admissionForm->batch_no?? ''); ?></td>
                                        <td><?php echo e($admissionStudentFilter->admissionForm->s_name?? ''); ?></td>
                                        <td><?php echo e($admissionStudentFilter->admissionForm->s_phone ?? ''); ?></td>
                                        <td><?php echo e($admissionStudentFilter->admissionForm->s_email ?? ''); ?></td>
                                        <td><?php echo e($admissionStudentFilter->total_fee ?? ''); ?>Tk.</td>
                                        <td><?php echo e($admissionStudentFilter->advance ?? ''); ?>Tk.</td>
                                        <td><?php echo e($admissionStudentFilter->due ?? ''); ?>Tk.</td>
                                    </tr>
                                    <?php
                                        if($admissionStudentFilter->admissionForm ? $admissionStudentFilter->admissionForm->course == 'web' : ''){
                                            $web += count(array($admissionStudentFilter->admissionForm->course));
                                        }
                                        if($admissionStudentFilter->admissionForm ? $admissionStudentFilter->admissionForm->course == 'digital' : ''){
                                            $adm += count(array($admissionStudentFilter->admissionForm->course));
                                        }
                                        $sum += $admissionStudentFilter->advance;
                                    ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td colspan="6"></td>
                                    <td>
                                        <span style="font-weight: bold">Total Amount : <?php echo e(number_format($sum,2)); ?></span>
                                    </td>
                                    <td>
                                        <span style="font-weight: bold">Total Web Admission : <?php echo e($web); ?></span>
                                    </td>
                                    <td>
                                        <span style="font-weight: bold">Total ADM Admission : <?php echo e($adm); ?></span>
                                    </td>
                                </tr>
                                </tbody>
                            <?php endif; ?>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.admin.admin-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\taskManagement\resources\views/backend/admin/home/admission-filtering.blade.php ENDPATH**/ ?>