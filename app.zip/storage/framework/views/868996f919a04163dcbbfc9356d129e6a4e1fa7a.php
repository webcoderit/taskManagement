<div class="sidebar-wrapper" data-simplebar="true">
  <div class="sidebar-header">
    <div>
        <img src="<?php echo e(asset('backend/')); ?>/logo.jpg" class="" alt="logo icon" style="width: 206px; height: 58px">
    </div>
  </div>
  <!--navigation-->
  <ul class="metismenu" id="menu">
    <li>
      <a href="<?php echo e(url('/admin/hr/dashboard')); ?>" class="has-arrow">
        <div class="parent-icon"><i class='bx bx-home-circle'></i>
        </div>
        <div class="menu-title">Dashboard</div>
      </a>
    </li>
    <li>
    <li>
      <a href="javascript:;" class="has-arrow">
        <div class="parent-icon"><i class='bx bx-user'></i>
        </div>
        <div class="menu-title">Students</div>
      </a>
      <ul>
        <li> <a href="<?php echo e(url('admin/student/list')); ?>"><i class="bx bx-right-arrow-alt"></i>Student list</a></li>
      </ul>
    </li>
    <li>
      <a class="has-arrow" href="javascript:;">
        <div class="parent-icon"><i class='bx bx-bookmark-heart'></i>
        </div>
        <div class="menu-title">Accounts</div>
      </a>
      <ul>
        <li> <a href="<?php echo e(url('/expanse')); ?>"><i class="bx bx-right-arrow-alt"></i>Expanse</a></li>
        <li> <a href="<?php echo e(url('/salary')); ?>"><i class="bx bx-right-arrow-alt"></i>Salary</a></li>
      </ul>
    </li>

  </ul>
  <!--end navigation-->
</div>
<?php /**PATH C:\xampp\htdocs\taskManagement\resources\views/backend/includes/hr-nav.blade.php ENDPATH**/ ?>