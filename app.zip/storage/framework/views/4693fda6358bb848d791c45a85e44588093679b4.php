<script src="<?php echo e(asset('backend/')); ?>/assets/js/bootstrap.bundle.min.js"></script>
	<!--plugins-->
	<script src="<?php echo e(asset('backend/')); ?>/assets/js/jquery.min.js"></script>
	<script src="<?php echo e(asset('backend/')); ?>/assets/plugins/simplebar/js/simplebar.min.js"></script>
	<script src="<?php echo e(asset('backend/')); ?>/assets/plugins/metismenu/js/metisMenu.min.js"></script>

	<script src="<?php echo e(asset('backend/')); ?>/assets/plugins/vectormap/jquery-jvectormap-2.0.2.min.js"></script>
	<script src="<?php echo e(asset('backend/')); ?>/assets/plugins/vectormap/jquery-jvectormap-world-mill-en.js"></script>






    <script src="<?php echo e(asset('backend/')); ?>/assets/plugins/datatable/js/jquery.dataTables.min.js"></script>
    <script src="<?php echo e(asset('backend/')); ?>/assets/plugins/datatable/js/dataTables.bootstrap5.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <script>
        $(document).ready(function() {
            $('#example').DataTable();
        } );
    </script>



	<script src="<?php echo e(asset('backend/')); ?>/assets/js/index2.js"></script>
	<!--app JS-->
	<script src="<?php echo e(asset('backend/')); ?>/assets/js/app.js"></script>
	<script src="<?php echo e(asset('backend/')); ?>/assets/js/custom.js"></script>
<script>
    // new PerfectScrollbar('.customers-list');
    // new PerfectScrollbar('.store-metrics');
    // new PerfectScrollbar('.product-list');
</script>
<?php /**PATH C:\xampp\htdocs\taskManagement\resources\views/backend/includes/script.blade.php ENDPATH**/ ?>