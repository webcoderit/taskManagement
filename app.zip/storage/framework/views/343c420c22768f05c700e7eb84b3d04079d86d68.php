

<?php $__env->startSection('content'); ?>
	<div class="wrapper">
	    <div class="page-wrapper" style="margin-left: 20px!important;">
	        <div class="page-content">
	            <!--breadcrumb-->
	            <div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
	                <div class="breadcrumb-title pe-3">Student List</div>
	                <div class="ps-3">
	                    <nav aria-label="breadcrumb">
	                        <ol class="breadcrumb mb-0 p-0">
	                            <li class="breadcrumb-item"><a href="<?php echo e(url('/admin/hr/dashboard')); ?>"><i class="bx bx-home-alt"></i></a>
	                            </li>
	                            <li class="breadcrumb-item active" aria-current="page">Student List</li>
	                        </ol>
	                    </nav>
	                </div>
	            </div>
	            <!--end breadcrumb-->
                <div class="col-md-12">
                    <div class="row">
                        <form action="<?php echo e(url('/admin/student/list')); ?>" method="get">
                            <div class="col-md-6 m-auto">
                                <div class="input-group mb-3">
                                    <?php echo csrf_field(); ?>
                                    <select class="form-control" name="batch_no">
                                        <option selected disabled>----Select A Batch No----</option>
                                        <?php $__currentLoopData = $admissionStudentsBatch; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admissionStudentBatch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($admissionStudentBatch[0]->batch_no); ?>"><?php echo e(ucfirst($admissionStudentBatch[0]->course)); ?> - <?php echo e(ucfirst($admissionStudentBatch[0]->batch_no)); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <button type="submit" class="input-group-text btn btn-primary" id="basic-addon2">Search</button>
                                    <a href="<?php echo e(url('/admin/student/list')); ?>" class="input-group-text btn btn-danger" id="basic-addon2">Clear</a>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
	            <hr/>
	            <div class="card">
	                <div class="card-body">
	                    <div class="table-responsive">
	                        <table id="" class="table table-striped table-bordered" style="width:100%">
	                            <thead>
	                            <tr>
	                                <th>SL</th>
	                                <th>Name</th>
	                                <th>Email</th>
	                                <th>Phone</th>
	                                <th>Course Name</th>
	                                <th>Course Fee</th>
	                                <th>Advance</th>
	                                <th>Due</th>
	                                <th>Action</th>
	                            </tr>
	                            </thead>
	                            <tbody>
                                <?php $__currentLoopData = $admissionStudents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admissionStudent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->index+1); ?></td>
                                        <td><?php echo e($admissionStudent->s_name?? ''); ?></td>
                                        <td><?php echo e($admissionStudent->s_email ?? ''); ?></td>
                                        <td><?php echo e($admissionStudent->s_phone ?? ''); ?></td>
                                        <td>
                                            <?php if($admissionStudent->course == 'web'): ?>
                                                Full stack web development
                                            <?php elseif($admissionStudent->course == 'digital'): ?>
                                                Advance digital marketing
                                            <?php else: ?>
                                                Communication english
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo e($admissionStudent->moneyReceipt->total_fee ?? ''); ?></td>
                                        <td><?php echo e($admissionStudent->moneyReceipt->advance ?? ''); ?></td>
                                        <td><?php echo e($admissionStudent->moneyReceipt->due ?? ''); ?></td>
                                        <td>
                                        	<a href="<?php echo e(url('/admin/admission/student/info/'.$admissionStudent->moneyReceipt->id)); ?>" class="btn btn-sm btn-primary">
                                                <i class="bx bx-edit-alt"></i>
                                                Due
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	                            </tbody>
	                        </table>
                            <?php echo e($admissionStudents->links()); ?>

	                    </div>
	                </div>
	            </div>
	        </div>
	    </div>
	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.admin.hr-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\taskManagement\resources\views/backend/admin/hrm/student-list.blade.php ENDPATH**/ ?>