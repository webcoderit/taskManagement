<?php $__env->startSection('content'); ?>
<div class="wrapper">
    <div class="page-wrapper" style="margin-left: 20px!important;">
        <div class="page-content">
            <!--breadcrumb-->
            <div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
                <div class="breadcrumb-title pe-3">Expanse</div>
                <div class="ps-3">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb mb-0 p-0">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('/admin/hr/dashboard')); ?>"><i class="bx bx-home-alt"></i></a>
                            </li>
                            <li class="breadcrumb-item active" aria-current="page">Expanse</li>
                        </ol>
                    </nav>
                </div>
            </div>
            <!--end breadcrumb-->
            <h6 class="mb-0 text-uppercase">Expanse</h6>
            <div class="add-expanse-btn-outer" style="text-align: end;">
                <a href="<?php echo e(url('/add/expanse')); ?>" style="display: inline-block;background: #f16522;color: #fff;padding: 7px 12px;border-radius: 5px;">
                    Add Expanse
                </a>
            </div>
            <hr/>
            <div class="card">
                <div class="card-body">












                    <form action="<?php echo e(url('/expanse')); ?>" method="get" class="form-group">
                        <?php echo csrf_field(); ?>
                        <div class="col-md-12">
                            <?php if(Session::has('success')): ?>
                                <div class="alert alert-success">
                                    <?php echo e(Session::get('success')); ?>

                                </div>
                            <?php endif; ?>
                            <div class="row">
                                <div class="col-md-5">
                                    <label>From date</label>
                                    <div class="input-group mb-2">
                                        <input type="date" name="from_date" class="form-control">
                                    </div>
                                </div>
                                <div class="col-md-5">
                                    <label>To date</label>
                                    <div class="input-group mb-2">
                                        <input type="date" name="to_date" class="form-control">
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <button type="submit" class="input-group-text btn btn-primary" id="basic-addon2" style="margin-top: 20px;">Search</button>
                                    <a href="<?php echo e(url('/expanse')); ?>" class="input-group-text btn btn-danger" id="basic-addon2" style="margin-top: 20px;">Clear</a>
                                </div>
                            </div>
                        </div>
                    </form>
                    <hr>
                    <div class="table-responsive">
                        <table id="" class="table table-striped table-bordered" style="width:100%">
                            <thead>
                            <tr>
                                <th>Date</th>
                                <th>User name</th>
                                <th>Bill Type</th>
                                <th>Amount</th>
                                <th>Minute</th>
                                <th width="40%">Note</th>
                                <th width="15%">Action</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php
                                $sum = 0
                            ?>
                            <?php $__currentLoopData = $expanses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $expanse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e(date('Y-m-d', strtotime($expanse->created_at))); ?></td>
                                    <td><?php echo e($expanse->user->full_name ?? 'No User Name'); ?></td>
                                    <td><?php echo e(ucfirst($expanse->bill_type)); ?> Bill</td>
                                    <td><?php echo e(number_format($expanse->price,2)); ?></td>
                                    <td><?php echo e($expanse->minute ?? '0'); ?> Minute</td>
                                    <td><?php echo e(ucfirst($expanse->note)); ?></td>
                                    <td>
                                        <a href="<?php echo e(url('/edit/expanse/'.$expanse->id)); ?>" class="btn btn-info">
                                            <i class="bx bx-edit-alt"></i>
                                        </a>
                                        
                                    </td>
                                </tr>
                                <?php
                                    $sum += $expanse->price
                                ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td width="8%">
                                    <span></span>
                                </td>
                                <td></td>
                                <td></td>
                                <td>
                                    <span style="font-weight: bold">Total Amount : <?php echo e(number_format($sum,2)); ?></span>
                                </td>
                            </tr>
                            </tbody>
                        </table>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.admin.hr-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\taskManagement\resources\views/backend/admin/hrm/expanse.blade.php ENDPATH**/ ?>