<?php $__env->startSection('content'); ?>
    <div class="wrapper">
        <div class="page-wrapper" style="margin-left: 20px!important;">
            <div class="page-content">
                <!--breadcrumb-->
                <div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
                    <div class="breadcrumb-title pe-3">Employee Tracking</div>
                    <div class="ps-3">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb mb-0 p-0">
                                <li class="breadcrumb-item"><a href="<?php echo e(url('/admin/dashboard')); ?>"><i class="bx bx-home-alt"></i></a>
                                </li>
                                <li class="breadcrumb-item active" aria-current="page">Employee Tracking</li>
                            </ol>
                        </nav>
                    </div>
                </div>
                <!--end breadcrumb-->
                <h6 class="mb-0 text-uppercase">Employee Tracking list</h6>
                <hr/>
                <div class="card">
                    <div class="card-body">
                        <div class="table-responsive">
                            <table id="example" class="table table-striped table-bordered" style="width:100%">
                                <thead>
                                <tr>
                                    <th>SL</th>
                                    <th>Name</th>
                                    <th>In time</th>
                                    <th>Out time</th>
                                    <th>Active Status</th>
                                </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($loop->index+1); ?></td>
                                            <?php if($user->status == 1): ?>
                                            <td class="user-online-offline-b">
                                                <img src="<?php echo e(asset('/avatar/'.$user->avatar)); ?>" height="30" width="30" style="border-radius: 50%" />
                                                <?php echo e($user->full_name ?? 'No name found'); ?>

                                            </td>
                                            <?php else: ?>
                                                <td class="user-online-offline-c">
                                                    <img src="<?php echo e(asset('/avatar/'.$user->avatar)); ?>" height="30" width="30" style="border-radius: 50%" />
                                                    <?php echo e($user->full_name ?? 'No name found'); ?>

                                                </td>
                                            <?php endif; ?>
                                            <td><?php echo e($user->in_time != null ? $user->in_time->format('g:i a') : '00:00'); ?></td>
                                            <td><?php echo e($user->out_time != null ? $user->out_time->format('g:i a') : '00:00'); ?></td>
                                            <td>
                                                <?php if($user->status == 1): ?>
                                                    <span class="custom-green-badge">Active</span>
                                                <?php else: ?>
                                                    <span class="custom-red-badge"><?php echo e($user->updated_at->diffforhumans()); ?></span>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
    <script>
        setInterval(function() {
            window.location.reload();
        }, 10000);
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('backend.admin.admin-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\taskManagement\resources\views/backend/admin/users/online.blade.php ENDPATH**/ ?>