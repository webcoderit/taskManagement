<?php $__env->startSection('content'); ?>
    <div class="wrapper">
        <div class="page-wrapper" style="margin-left: 20px!important;">
            <div class="page-content">
                <!--breadcrumb-->
                <div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
                    <div class="breadcrumb-title pe-3">All Task</div>
                    <div class="ps-3">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb mb-0 p-0">
                                <li class="breadcrumb-item"><a href="<?php echo e(url('/employee/dashboard')); ?>"><i class="bx bx-home-alt"></i></a>
                                </li>
                                
                                <li class="breadcrumb-item active" aria-current="page">All Task</li>
                            </ol>
                        </nav>
                    </div>
                </div>
                <!--end breadcrumb-->
                <h6 class="mb-0 text-uppercase">All Task</h6>
                <hr/>
                <div class="card">
                    <div class="card-body">
                        <form class="form-group" action="<?php echo e(url('/all/task')); ?>" method="get">
                            <?php echo csrf_field(); ?>
                            <div class="col-md-12" style="padding-left: 10%;">
                                <div class="row">
                                    <div class="col-md-3"></div>
                                    <div class="col-md-4">
                                        <input type="search" name="search" class="form-control" placeholder="Enter Phone Number & Full Name">
                                    </div>
                                    <div class="col-md-2">
                                        <div class="input-group">
                                            <button type="submit" class="input-group-text btn btn-primary" id="basic-addon2">Search</button>
                                            <a href="<?php echo e(url('/all/task')); ?>" class="input-group-text btn btn-danger" id="basic-addon2">Clear</a>
                                        </div>
                                    </div>
                                    <div class="col-md-3" style="text-align-last: end;"></div>
                                </div>
                            </div>
                        </form>
                        <div class="table-responsive mt-3">
                            <table id="" class="table table-striped table-bordered" style="width:100%">
                                <thead>
                                <tr>
                                    <th>SL</th>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Phone</th>
                                    <th>Profession</th>
                                    <th>interested Level</th>
                                    <th>Status</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $allTask; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->index+1); ?></td>
                                        <td><?php echo e($task->name ?? ' '); ?></td>
                                        <td><?php echo e($task->email ?? ' '); ?></td>
                                        <td><?php echo e($task->phone ?? ' '); ?></td>
                                        <td><?php echo e($task->interestes ? ucfirst($task->interestes->profession) : ' '); ?></td>
                                        <td>
                                            <?php echo e($task->interestes ? ucfirst($task->interestes->interest_level) : ' '); ?>

                                        </td>
                                        <td>
                                            <?php if($task->status == 1): ?>
                                                <span class="btn btn-sm btn-success">Call Done</span>
                                            <?php else: ?>
                                                <span class="btn btn-sm btn-danger">Pending</span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                        <?php echo e($allTask->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\taskManagement\resources\views/backend/users/task/all-task.blade.php ENDPATH**/ ?>