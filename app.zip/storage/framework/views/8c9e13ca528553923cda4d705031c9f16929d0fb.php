<header>
    <div class="topbar d-flex align-items-center bg-dark shadow-none border-light-2 border-bottom">
        <nav class="navbar navbar-expand">
            <div class="mobile-toggle-menu text-white me-3"><i class='bx bx-menu'></i>
            </div>
            <div class="top-menu-left d-none d-lg-block">

            </div>
            <div class="top-menu ms-auto"></div>
            <div class="user-box dropdown border-light-2">
                <a class="d-flex align-items-center nav-link dropdown-toggle dropdown-toggle-nocaret" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">

                    <?php if(auth()->check()): ?>
                    <img src="<?php echo e(asset('/avatar/'.auth()->user()->avatar)); ?>" class="user-img" alt="user avatar">
                    <?php endif; ?>
                    <div class="user-info ps-3">
                        <?php if(auth()->check()): ?>
                            <p class="user-name mb-0 text-white"><?php echo e(auth()->user()->full_name); ?></p>
                        <?php endif; ?>
                    </div>
                </a>
                <ul class="dropdown-menu dropdown-menu-end">
                    <li><a class="dropdown-item" href="<?php echo e(url('/profile/setting')); ?>"><i class="bx bx-cog"></i><span>Settings</span></a>
                    </li>
                    <li><div class="dropdown-divider mb-0"></div></li>
                    <li>
                        <a class="dropdown-item" href="#" onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                            <i class='bx bx-log-out-circle'></i>
                            <span>Logout</span>
                        </a>
                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                            <?php echo csrf_field(); ?>
                        </form>
                    </li>
                </ul>
            </div>
        </nav>
    </div>
</header>
<?php /**PATH C:\xampp\htdocs\taskManagement\resources\views/backend/includes/header.blade.php ENDPATH**/ ?>