<?php $__env->startSection('content'); ?>
	<div class="wrapper">
	    <div class="page-wrapper" style="margin-left: 20px!important;">
	        <div class="page-content">
                <?php if(Session::has('success')): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <strong>Success!</strong> <?php echo e(Session::get('success')); ?>.
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>
	            <!--breadcrumb-->
	            <div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
	                <div class="breadcrumb-title pe-3">Student Due List</div>
	                <div class="ps-3">
	                    <nav aria-label="breadcrumb">
	                        <ol class="breadcrumb mb-0 p-0">
	                            <li class="breadcrumb-item"><a href="<?php echo e(url('/admin/dashboard')); ?>"><i class="bx bx-home-alt"></i></a>
	                            </li>
	                            <li class="breadcrumb-item active" aria-current="page">Student Due List</li>
	                        </ol>
	                    </nav>
	                </div>
	            </div>
	            <!--end breadcrumb-->
                <div class="col-md-12">
                    <form action="<?php echo e(url('/admin/user/due/report')); ?>" method="get" class="form-group">
                        <?php echo csrf_field(); ?>
                        <div class="col-md-12">
                            <div class="row">
                                <div class="col-md-4">
                                    <label>From date</label>
                                    <div class="input-group mb-2">
                                        <input type="date" name="from_date" class="form-control">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <label>To date</label>
                                    <div class="input-group mb-2">
                                        <input type="date" name="to_date" class="form-control">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <button type="submit" class="input-group-text btn btn-primary" id="basic-addon2" style="margin-top: 20px;">Search</button>
                                    <a href="<?php echo e(url('/admin/user/due/report')); ?>" class="input-group-text btn btn-danger" id="basic-addon2" style="margin-top: 20px;">Clear</a>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
	            <hr/>
	            <div class="card">
	                <div class="card-body">
                        <form class="form-group" action="<?php echo e(url('/admin/user/due/report')); ?>" method="get">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-md-3">
                                    <label for="batch" style="font-weight: 600; margin-bottom: 5px;">
                                        Batch No:
                                    </label><br>
                                    <select name="batch_no" id="batchNo" class="form-control">
                                        <option selected disabled>--- Select Batch No ---</option>
                                        <?php $__currentLoopData = $batchs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $batchNo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($batchNo->batch_no); ?>"><?php echo e(ucfirst($batchNo->course_name)); ?> - <?php echo e($batchNo->batch_no); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="col-md-3">
                                    <div class="input-group" style="margin-top: 25px;">
                                        <button type="submit" class="input-group-text btn btn-primary">
                                            Search
                                        </button>
                                        <a href="<?php echo e(url('/admin/user/due/report')); ?>" class="input-group-text btn btn-danger">
                                            Clear
                                        </a>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <?php if(isset($admissionStudents) > 0): ?>
                                    <label for="batch" style="font-weight: 600; margin-bottom: 10px;">
                                        Total Student:
                                    </label><br>
                                        <span class="total-student-count">
                                            <?php echo e(count($admissionStudents)); ?>

                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </form>
	                    <div class="table-responsive mt-3">

	                        <table id="" class="table table-striped table-bordered">
	                            <thead>
	                            <tr>
	                                <th>Due Collect Date</th>
	                                <th>Marketing Officer Name</th>
	                                <th>Name</th>
	                                <th>Phone</th>
                                    <th width="15%">Student FB ID</th>
	                                <th>Course Name</th>
	                                <th>Batch No</th>
	                                <th>Course Fee</th>
	                                <th>First Payment</th>
	                                <th>Second Payment</th>
	                                <th>Due</th>
	                                <th>Due Opinion</th>
	                                
	                                
	                            </tr>
	                            </thead>
	                            <tbody>
                                <?php $__currentLoopData = $admissionStudents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admissionStudent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                            <?php if($admissionStudent->moneyReceipt->is_pay == 1): ?>
                                                <?php echo e($admissionStudent->moneyReceipt->updated_at->format('Y-m-d')); ?> <br/>
                                                <a href="<?php echo e(url('/paid/money/receipt/download/'.$admissionStudent->id)); ?>" class="btn btn-sm btn-facebook" title="Download Money Receipt">
                                                    <i class="bx bx-download"></i>
                                                </a>
                                            <?php else: ?>
                                                <span>Not paid yet</span>
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo e($admissionStudent->user->full_name?? session()->get('name')); ?></td>
                                        <td><?php echo e($admissionStudent->s_name?? ''); ?></td>
                                        <td><?php echo e($admissionStudent->s_phone ?? ''); ?></td>
                                        <td width="15%">
                                            <a href="<?php echo e($admissionStudent->fb_id ?? ''); ?>" target="_blank"><?php echo e(Str::substr($admissionStudent->fb_id, 0, 50) ?? ''); ?></a>
                                        </td>
                                        <td>
                                            <?php if($admissionStudent->course == 'web'): ?>
                                                Web
                                            <?php elseif($admissionStudent->course == 'digital'): ?>
                                                ADM
                                            <?php else: ?>
                                                Eng
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo e($admissionStudent->batch_no ?? ''); ?></td>
                                        <td><?php echo e($admissionStudent->moneyReceipt->total_fee ?? ''); ?>Tk.</td>
                                        <td><?php echo e($admissionStudent->moneyReceipt->advance ?? ''); ?>Tk.</td>
                                        <td><?php echo e($admissionStudent->moneyReceipt->today_pay ?? 'Not yet'); ?></td>
                                        <td><?php echo e($admissionStudent->moneyReceipt->due ?? ''); ?>Tk.</td>
                                        <td><?php echo e($admissionStudent->note ?? ''); ?></td>
                                        
                                        
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	                            </tbody>
	                        </table>
	                    </div>
	                </div>
	            </div>
	        </div>
	    </div>
	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.admin.admin-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\taskManagement\resources\views/backend/admin/home/due-collect.blade.php ENDPATH**/ ?>