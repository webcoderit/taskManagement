<?php $__env->startSection('content'); ?>
	<div class="wrapper">
	    <div class="page-wrapper" style="margin-left: 20px!important;">
	        <div class="page-content">
                <?php if(Session::has('success')): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <strong>Success!</strong> <?php echo e(Session::get('success')); ?>.
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>
	            <!--breadcrumb-->
	            <div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
	                <div class="breadcrumb-title pe-3">Student Reject List</div>
	                <div class="ps-3">
	                    <nav aria-label="breadcrumb">
	                        <ol class="breadcrumb mb-0 p-0">
	                            <li class="breadcrumb-item"><a href="<?php echo e(url('/admin/hr/dashboard')); ?>"><i class="bx bx-home-alt"></i></a>
	                            </li>
	                            <li class="breadcrumb-item active" aria-current="page">Student Reject List</li>
	                        </ol>
	                    </nav>
	                </div>
	            </div>
	            <!--end breadcrumb-->






























	            <div class="card">
	                <div class="card-body">
	                    <div class="table-responsive">
	                        <table id="" class="table table-striped table-bordered">
	                            <thead>
	                            <tr>
	                                <th>SL</th>
	                                <th>Marketing Officer Name</th>
	                                <th>Name</th>
	                                <th>Email</th>
	                                <th>Phone</th>
                                    <th>Student FB ID</th>
	                                <th>Course Name</th>
	                                <th>Batch No</th>
	                                <th>Course Fee</th>
                                    <th>First Payment</th>
                                    <th>Second Payment</th>
	                                <th>Due</th>
	                                <th>Due Opinion</th>
	                                <th>Admission Opinion</th>
	                                <th>Action</th>
	                            </tr>
	                            </thead>
	                            <tbody>
                                <?php $__currentLoopData = $admissionRejectStudents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admissionStudent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->index+1); ?></td>
                                        <td><?php echo e($admissionStudent->user->full_name?? session()->get('name')); ?></td>
                                        <td><?php echo e($admissionStudent->s_name?? ''); ?></td>
                                        <td><?php echo e($admissionStudent->s_email ?? ''); ?></td>
                                        <td><?php echo e($admissionStudent->s_phone ?? ''); ?></td>
                                        <td>
                                            <a href="<?php echo e($admissionStudent->fb_id ?? ''); ?>" target="_blank"><?php echo e($admissionStudent->fb_id ?? ''); ?></a>
                                        </td>
                                        <td>
                                            <?php if($admissionStudent->course == 'web'): ?>
                                                Web
                                            <?php elseif($admissionStudent->course == 'digital'): ?>
                                                ADM
                                            <?php else: ?>
                                                Eng
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo e($admissionStudent->batch_no ?? ''); ?></td>
                                        <td><?php echo e($admissionStudent->moneyReceipt->total_fee ?? ''); ?>Tk.</td>
                                        <td><?php echo e($admissionStudent->moneyReceipt->advance ?? ''); ?>Tk.</td>
                                        <td><?php echo e($admissionStudent->moneyReceipt->today_pay ?? 'Not yet'); ?></td>
                                        <td><?php echo e($admissionStudent->moneyReceipt->due ?? ''); ?>Tk.</td>
                                        <td><?php echo e($admissionStudent->note ?? ''); ?></td>
                                        <td><?php echo e($admissionStudent->other_admission_note ?? ''); ?></td>
                                        <td>
                                            <?php if($admissionStudent->is_reject == 1): ?>
                                                <a href="<?php echo e(url('/admin/student/restore/'.$admissionStudent->id)); ?>" class="btn btn-sm btn-warning">
                                                    <i class="bx bx-refresh"></i>
                                                </a>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	                            </tbody>
	                        </table>
	                    </div>
	                </div>
	            </div>
	        </div>
	    </div>
	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.admin.hr-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\taskManagement\resources\views/backend/admin/hrm/student-reject-list.blade.php ENDPATH**/ ?>